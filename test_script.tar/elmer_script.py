def run(data=None):
    import os
    import sys
    from datetime import datetime
    from pathlib import Path
    import logging
    
    import numpy as np
    
    # Use test data if no data provided
    if not data:
        data = {
            'input': {
                'r': [50., 80., 100.],
                
                'k': [0.15, 1.5, 51.9, 12.],
            },
            'task': {
                'work_dir': Path('/home/nwen/metamaterial-rl/elmer_harv/test_workdir').absolute(),
                'data_dir': Path('/home/nwen/metamaterial-rl/elmer_harv/data').absolute(),
            },
            'metrics': {
                'submit_timestamp': datetime.now(),
            }
        }
     
    workdir = data['task']['work_dir']

    import gmsh
    import pyvista as pv
    
    from scipy.spatial import cKDTree

    from pyelmer import elmer
    from pyelmer import execute
    from pyelmer.post import scan_logfile
    from objectgmsh.utils import add_physical_group, get_boundaries_in_box

    wait_time = (datetime.now() - data['metrics']['submit_timestamp']).total_seconds()
        
    def cut_fragment(objectDimTags, toolDimTags):
        import gmsh
        factory = gmsh.model.occ

        cutDimTags, _ = factory.cut(objectDimTags, toolDimTags, removeTool=False)
        fragDimTags, _ = factory.fragment(cutDimTags, toolDimTags)
        return cutDimTags, fragDimTags

    gmsh.model.occ.cut_fragment = cut_fragment

    ###############
    os.environ['OMP_NUM_THREADS'] = '1'

    start_time = datetime.now()

    gmsh.initialize()
    
    gmsh.option.setNumber("General.Terminal", 1)
    gmsh.model.add("heat-transfer-2d")
    factory = gmsh.model.occ

    mesh_size = 20.


    board_size = (400., 400.)
    board_center = (board_size[0] / 2, board_size[1] / 2)

    # Region 0~2, 0 is the center circle, 1 is ring in the middle, 2 is the outer ring, 3/board is the remaining of the board
    # r[0~2] is radius of the outer boundry, k[0~2] is the conductivity 
    r = data['input']['r']
    r0 = r[0]
    r1 = r[1]
    r2 = r[2]

    k = data['input']['k']
    
    # cap lower to 0.1 to deal with 0 states
    k0 = max(k[0], 0.1)
    k1 = max(k[1], 0.1)
    k2 = max(k[2], 0.1)
    k3 = max(k[3], 0.1)

  
    board_tag = factory.add_rectangle(0, 0, 0, *board_size)

    # # Cut outer ring (region 2)

    region2_tag = factory.add_circle(board_size[0] / 2, board_size[1] / 2, 0, r2)
    region2_tag = factory.add_curve_loop([region2_tag])
    region2_tag = factory.add_plane_surface([region2_tag])

    region3_tag, _ = factory.cut_fragment([(2, board_tag)], [(2, region2_tag)])
    region3_tag = region3_tag[0][1]

    # Cut middle ring (region 1)

    region1_tag = factory.add_circle(board_size[0] / 2, board_size[1] / 2, 0, r1)
    region1_tag = factory.add_curve_loop([region1_tag])
    region1_tag = factory.add_plane_surface([region1_tag])

    region2_tag, _ = factory.cut_fragment([(2, region2_tag)], [(2, region1_tag)])
    region2_tag = region2_tag[0][1]

    # Cut inner circle (region 0)

    region0_tag = factory.add_circle(board_size[0] / 2, board_size[1] / 2, 0, r0)
    region0_tag = factory.add_curve_loop([region0_tag])
    region0_tag = factory.add_plane_surface([region0_tag])

    region1_tag, _ = factory.cut_fragment([(2, region1_tag)], [(2, region0_tag)])
    region1_tag = region1_tag[0][1]

    factory.synchronize()


    # frame_tags = [dimtag[1] for dimtag in frame_dimtags]
    # infill_tags = [dimtag[1] for dimtag in stripe_dimtags]

    phy_region0 = add_physical_group(2, [region0_tag], "region0")
    phy_region1 = add_physical_group(2, [region1_tag], "region1")
    phy_region2 = add_physical_group(2, [region2_tag], "region2")
    phy_region3 = add_physical_group(2, [region3_tag], "region3")

    left_bound = get_boundaries_in_box(0., 0., 0., 0., board_size[1], 0., 2, region3_tag)
    right_bound = get_boundaries_in_box(board_size[0], 0., 0., board_size[0], board_size[1], 0., 2, region3_tag)

    phy_left = add_physical_group(1, [left_bound], "left_bound")
    phy_right = add_physical_group(1, [right_bound], "right_bound")

    # create mesh
    gmsh.model.mesh.setSize(gmsh.model.getEntities(0), mesh_size)
    gmsh.model.mesh.generate(2)
    gmsh.write(str(workdir / 'case.msh'))
    
    mesh_retries = 2
    
    while (not (workdir / 'case.msh').exists()) or (workdir / 'case.msh').stat().st_size < 500:
        if mesh_retries > 0:
            print('Meshing failed, retrying...')
            gmsh.model.mesh.generate(2)
            gmsh.write(str(workdir / 'case.msh'))
            mesh_retries -= 1
        else:
            raise ArithmeticError('Failed to mesh the geometries')
            
    print('Mesh generated')

    mesh_time = datetime.now() - start_time
    mesh_time = mesh_time.total_seconds()

    start_time = datetime.now()

    ###############
    # elmer setup
    elmer.data_dir = data['task']['data_dir']

    sim = elmer.load_simulation("2D_steady")

    solver_heat = elmer.load_solver("HeatSolver", sim)
    solver_output = elmer.load_solver("ResultOutputSolver", sim)
    eqn = elmer.Equation(sim, "main", [solver_heat])

    T0 = elmer.InitialCondition(sim, "T0", {"Temperature": 273.15})

    body_region0 = elmer.Body(sim, "region0", [phy_region0])
    body_region0.material = elmer.Material(sim, 'm0', {'Heat Conductivity': k0})
    body_region0.initial_condition = T0
    body_region0.equation = eqn

    body_region1 = elmer.Body(sim, "region1", [phy_region1])
    body_region1.material = elmer.Material(sim, "m1", {'Heat Conductivity': k1})
    body_region1.initial_condition = T0
    body_region1.equation = eqn

    body_region2 = elmer.Body(sim, "region2", [phy_region2])
    body_region2.material = elmer.Material(sim, "m2", {'Heat Conductivity': k2})
    body_region2.initial_condition = T0
    body_region2.equation = eqn

    body_region3 = elmer.Body(sim, "region3", [phy_region3])
    body_region3.material = elmer.Material(sim, "m3", {'Heat Conductivity': k3})
    body_region3.initial_condition = T0
    body_region3.equation = eqn

    boundary_left = elmer.Boundary(sim, "left_bound", [phy_left])
    boundary_left.data.update({"Temperature": 373.15})  # 100 °C
    boundary_right = elmer.Boundary(sim, "right_bound", [phy_right])
    boundary_right.data.update({"Temperature": 293.15})  # 20 °C

    sim.write_startinfo(str(workdir))
    sim.write_sif(str(workdir))

    ##############
    # execute ElmerGrid & ElmerSolver
    execute.run_elmer_grid(str(workdir), "case.msh")
    execute.run_elmer_solver(str(workdir))
    
    import subprocess
    with open(data['task']['work_dir'] / 'debug.log', 'w') as fp:
        sp = subprocess.run('ElmerSolver case.sif', shell=True, stdout=fp, stderr=fp)
        fp.write(f'exit({sp.returncode})\n')
        
        sp = subprocess.run('module list', shell=True, stdout=fp, stderr=fp)
        fp.write(f'exit({sp.returncode})\n')
        
        sp = subprocess.run('lscpu', shell=True, stdout=fp, stderr=fp)
        fp.write(f'exit({sp.returncode})\n')
        
        sp = subprocess.run('env', shell=True, stdout=fp, stderr=fp)
        fp.write(f'exit({sp.returncode})\n')
    
    print('FEM solved')
      
    
    ###############
    # scan log for errors and warnings
    err, warn, stats = scan_logfile(str(workdir))
    print("Errors:", err)
    print("Warnings:", warn)
    print("Statistics:", stats)

    solve_time = datetime.now() - start_time
    solve_time = solve_time.total_seconds()

    start_time = datetime.now()

    extraction_resolution = (10, 10)

    m = pv.read(str(workdir / 'case_t0001.vtu'))
    m.set_active_scalars('temperature')

    kdtree = cKDTree(m.points.astype(np.double))

    sampling_mesh = np.mgrid[0.:board_size[0]:extraction_resolution[0], 0.:board_size[1]:extraction_resolution[1]]
    sampling_spot = sampling_mesh.T.reshape((sampling_mesh.shape[1] * sampling_mesh.shape[2], 2))
    dist, index = kdtree.query(np.hstack((sampling_spot, np.zeros((sampling_spot.shape[0], 1), dtype=sampling_spot.dtype))))

    values = m.active_scalars[index]
    result = np.hstack([sampling_spot, values.reshape((values.shape[0], 1))]).T
    
    ta = m.active_scalars[kdtree.query([  -r2 + 200.,   200.,   0.])[1]]
    tb = m.active_scalars[kdtree.query([  -r0 + 200.,   200.,   0.])[1]]
    tc = m.active_scalars[kdtree.query([  r0 + 200.,   200.,   0.])[1]]
    td = m.active_scalars[kdtree.query([  r2 + 200.,   200.,   0.])[1]]
    
    eta = np.abs(tb - tc) / np.abs(ta - td)
    
    print('Spatial data extracted')

    extract_time = datetime.now() - start_time
    extract_time = extract_time.total_seconds()
    
    data['output'] = {
        'temperature_distribution': result,
        'temp_abcd': (ta, tb, tc, td),
        'eta': eta,
    }
    data['output_files'] = {}
    data['metrics'] |= {
        'wait_time': wait_time,
        'mesh_time': mesh_time,
        'solve_time': solve_time,
        'extract_time': extract_time,
        'mesh_retries': 2 - mesh_retries,
    }

    return data


if __name__ == '__main__':
    from pprint import pprint
    
    result = run(None)
    
    pprint(result)
    